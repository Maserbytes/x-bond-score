/**
 * BondScore - Content Script Coordinator (Multi-Platform: X, Threads, Bluesky)
 * Observes timeline DOM mutations, coordinates badge injection, and handles SPA navigation.
 */

(async function () {
  // Prevent duplicate script execution
  if (window.__bondScoreContentScriptLoaded) return;
  window.__bondScoreContentScriptLoaded = true;

  // Initialize storage
  if (window.bondStorage) {
    await window.bondStorage.init();
  }

  // 1. Determine active platform from hostname
  const hostname = location.hostname.toLowerCase();
  let activePlatform = 'x';
  if (hostname.includes('threads.net')) {
    activePlatform = 'threads';
  } else if (hostname.includes('bsky.app')) {
    activePlatform = 'bsky';
  } else {
    activePlatform = 'x';
  }

  console.log(`[BondScore] Initializing on platform: ${activePlatform} (${hostname})`);

  // 2. Check if platform is enabled in user settings
  const isEnabled = window.bondStorage ? window.bondStorage.isPlatformEnabled(activePlatform) : (activePlatform === 'x');
  if (!isEnabled) {
    console.log(`[BondScore] Platform '${activePlatform}' is currently disabled in user settings. Skipping DOM observers.`);
    // Listen for settings change in case user turns it on from popup
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.settings) {
          const newSettings = changes.settings.newValue || {};
          const p = newSettings.platforms && newSettings.platforms[activePlatform];
          if (p && p.enabled) {
            location.reload();
          }
        }
      });
    }
    return;
  }

  // 3. Initialize appropriate platform adapter
  let adapter = null;
  if (activePlatform === 'threads' && window.ThreadsPlatformAdapter) {
    adapter = new window.ThreadsPlatformAdapter();
    await adapter.init();
  } else if (activePlatform === 'bsky' && window.BskyPlatformAdapter) {
    adapter = new window.BskyPlatformAdapter();
    await adapter.init();
  } else {
    adapter = new window.XPlatformAdapter();
    if (window.interactionDetector) {
      await window.interactionDetector.init();
      await adapter.init(window.interactionDetector);
    }
  }

  let scanScheduled = false;
  let isScanning = false;
  let lastUrl = location.href;
  const historyBackfillScheduled = new Set();

  async function scheduleRecentHistoryBackfill(handle, currentUser) {
    const cleanHandle = (handle || '').replace(/^@/, '').toLowerCase().trim();
    if (!cleanHandle || !currentUser || historyBackfillScheduled.has(cleanHandle)) return;

    if (window.bondStorage) {
      await window.bondStorage.rebuildDirectionalStats(cleanHandle).catch(() => {});
      const user = await window.bondStorage.getUser(cleanHandle);
      if (user && user.historyBackfillAt) return;
      if (user && Date.now() - (user.historyBackfillAttemptAt || 0) < 24 * 60 * 60 * 1000) return;

      historyBackfillScheduled.add(cleanHandle);
      await window.bondStorage.saveUser(cleanHandle, { historyBackfillAttemptAt: Date.now() });
    }

    if (window.deepAnalyzer && activePlatform === 'x') {
      setTimeout(() => {
        window.deepAnalyzer.runAnalysis(currentUser, cleanHandle, () => {}, { windowDays: 7 })
          .catch(() => {})
          .finally(() => historyBackfillScheduled.delete(cleanHandle));
      }, 250);
    }
  }

  /**
   * Scans visible DOM for posts, profile headers, and chats to inject BondScore badges.
   */
  async function scanDom() {
    scanScheduled = false;
    if (isScanning) return;
    isScanning = true;

    try {
      if (activePlatform === 'threads' && adapter) {
        const cur = adapter.extractActiveAccountFromDOM();
        if (cur && cur.handle) adapter.setCurrentUser(cur.handle);
        await adapter.scanTimeline(adapter.currentUser);
        await adapter.scanProfile(adapter.currentUser);
        await adapter.scanDms();
      } else if (activePlatform === 'bsky' && adapter) {
        const cur = adapter.extractActiveAccountFromDOM();
        if (cur && cur.handle) adapter.setCurrentUser(cur.handle);
        await adapter.scanTimeline(adapter.currentUser);
        await adapter.scanProfile(adapter.currentUser);
        await adapter.scanDms();
      } else {
        // Platform: X (Twitter)
        if (window.interactionDetector) {
          await window.interactionDetector.checkAccountSwitch();
        }

        const currentUser = window.interactionDetector ? window.interactionDetector.currentUser : null;

        // 1. Process Timeline Tweets
        const tweets = document.querySelectorAll('article[data-testid="tweet"]');
        for (const tweet of tweets) {
          try {
            if (window.interactionDetector) {
              await window.interactionDetector.detectIncomingTweet(tweet);
            }

            const userNameContainer = tweet.querySelector('[data-testid="User-Name"]');
            if (!userNameContainer) continue;

            const existingBadges = userNameContainer.querySelectorAll('.bond-badge');
            if (existingBadges.length > 0) {
              for (let i = 1; i < existingBadges.length; i++) existingBadges[i].remove();
              continue;
            }

            if (userNameContainer.getAttribute('data-bond-injected')) continue;

            const author = window.interactionDetector ? window.interactionDetector.extractTweetAuthor(tweet) : null;
            if (!author || !author.handle) continue;
            if (currentUser && author.handle === currentUser) continue;

            userNameContainer.setAttribute('data-bond-injected', 'true');
            if (window.bondUI) {
              await window.bondUI.injectBadge(userNameContainer, author.handle, false, 'x');
            }
          } catch (err) {}
        }

        // 2. Process Notifications
        if (location.pathname.startsWith('/notifications') && window.interactionDetector) {
          const cells = document.querySelectorAll('[data-testid="cellInnerDiv"]');
          for (const cell of cells) {
            try {
              await window.interactionDetector.detectNotificationCell(cell);
            } catch (e) {}
          }
        }

        // 3. Process Profile Page Header & Relationship Signals
        const profileMatch = location.pathname.match(/^\/([A-Za-z0-9_]+)$/);
        if (profileMatch && profileMatch[1]) {
          const profileHandle = profileMatch[1].toLowerCase();
          const nonUserPaths = ['home', 'explore', 'notifications', 'messages', 'settings', 'i', 'compose', 'search'];
          if (!nonUserPaths.includes(profileHandle) && (!currentUser || profileHandle !== currentUser)) {
            const profileHeader = document.querySelector('div[data-testid="UserName"]');
            if (profileHeader) {
              const existingHeaderBadges = profileHeader.querySelectorAll('.bond-badge');
              if (existingHeaderBadges.length > 0) {
                for (let i = 1; i < existingHeaderBadges.length; i++) existingHeaderBadges[i].remove();
              } else if (!profileHeader.getAttribute('data-bond-injected')) {
                profileHeader.setAttribute('data-bond-injected', 'true');
                if (window.bondUI) {
                  await window.bondUI.injectBadge(profileHeader, profileHandle, true, 'x');
                }
              }
            }
            if (window.interactionDetector) {
              await window.interactionDetector.observeProfileSignals(profileHandle);
            }
            scheduleRecentHistoryBackfill(profileHandle, currentUser).catch(() => {});
          }
        }

        // 4. Process Direct Messages
        if (location.pathname.startsWith('/messages') || document.querySelector('[data-testid="DMDrawer"]')) {
          if (window.interactionDetector) {
            await window.interactionDetector.scanDmInbox();
            await window.interactionDetector.scanActiveDmThread();
          }
        }
      }

      // 4. Process Direct Messages (Conversation row badges & open thread header pill)
      if (location.pathname.startsWith('/messages') || document.querySelector('[data-testid="DMDrawer"]')) {
        await window.interactionDetector.scanDmInbox();
        await window.interactionDetector.scanActiveDmThread();
      }
    } finally {
      isScanning = false;
    }
  }

  function scheduleScan() {
    if (scanScheduled) return;
    scanScheduled = true;
    requestAnimationFrame(() => {
      setTimeout(scanDom, 120);
    });
  }

  // Set up MutationObserver to monitor timeline feeds
  const observer = new MutationObserver((mutations) => {
    let hasRelevantNodes = false;
    for (const m of mutations) {
      if (m.addedNodes.length > 0) {
        hasRelevantNodes = true;
        break;
      }
    }
    if (hasRelevantNodes) {
      scheduleScan();
    }
  });

  const root = document.getElementById('react-root') || document.body;
  if (root) {
    observer.observe(root, { childList: true, subtree: true });
  }

  // Listen for popup inquiries for active tab account
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === 'bondscore:get_active_account') {
        let info = null;
        if (activePlatform === 'threads' && adapter) {
          info = adapter.extractActiveAccountFromDOM();
        } else if (activePlatform === 'bsky' && adapter) {
          info = adapter.extractActiveAccountFromDOM();
        } else if (window.interactionDetector) {
          info = window.interactionDetector.extractActiveAccountFromDOM();
        }
        sendResponse({
          platform: activePlatform,
          handle: info ? info.handle : null,
          metadata: info || null
        });
        return true;
      }
    });
  }

  // SPA URL change detection & active account switch check
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (window.interactionDetector && activePlatform === 'x') {
        window.interactionDetector.checkAccountSwitch();
      }
      scheduleScan();
    }
  }, 500);

  // Periodic active account verification
  setInterval(() => {
    if (window.interactionDetector && activePlatform === 'x') {
      window.interactionDetector.checkAccountSwitch();
    }
  }, 2000);

  // Initial scan
  setTimeout(scanDom, 600);
})();
