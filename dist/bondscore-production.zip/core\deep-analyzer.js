/**
 * BondScore for X - Modular Deep Analysis Engine
 * Allows on-demand deep scanning of mutual interactions between the current user and any target account.
 * Designed to easily plug in custom search/scraping methods (e.g. from Rezero Sanctuary).
 */

/** Handles can arrive from DOM input, events or storage; always coerce safely. */
function normalizeHandle(value) {
  return String(value === null || value === undefined ? '' : value)
    .trim()
    .replace(/^@/, '')
    .toLowerCase()
    .trim();
}

class BaseDeepProvider {
  constructor(name = 'BaseProvider') {
    this.name = name;
  }

  /**
   * Must be implemented by custom providers.
   * @param {string} currentUser - handle of logged-in user
   * @param {string} targetUser - handle of user being analyzed
   * @param {Function} onProgress - callback({ percent: number, stage: string, itemsFound: number })
   * @returns {Promise<Array<{ type: string, timestamp: number, tweetId: string, textSnippet: string, isMutual: boolean }>>}
   */
  async analyze(currentUser, targetUser, onProgress, options = {}) {
    throw new Error('Not implemented');
  }
}

/**
 * Default Provider: Advanced X Search & DOM Scraper
 * Uses X's native search queries:
 *   (from:userA to:userB) OR (from:userB to:userA)
 * Queries X's internal timeline or searches via background session.
 */
class XSearchQueryAnalyzer extends BaseDeepProvider {
  constructor() {
    super('XSearchQueryAnalyzer');
  }

  async analyze(currentUser, targetUser, onProgress, options = {}) {
    const cleanCurrent = normalizeHandle(currentUser);
    const cleanTarget = normalizeHandle(targetUser);

    if (!cleanCurrent || !cleanTarget) {
      throw new Error('Both currentUser and targetUser are required for Deep Analysis');
    }

    onProgress({ percent: 10, stage: 'Preparing interaction query...', itemsFound: 0 });

    const windowDays = Math.max(1, Math.min(7, Number(options.windowDays) || 7));
    const since = new Date(Date.now() - windowDays * 86400000).toISOString().slice(0, 10);
    const searchQuery = `((from:${cleanCurrent} to:${cleanTarget}) OR (from:${cleanTarget} to:${cleanCurrent})) since:${since}`;
    console.log(`[BondScore] Deep analyzing via query: ${searchQuery}`);

    // Check if user has plugged in a custom function (e.g. Rezero Sanctuary)
    if (window.customDeepAnalysisFunction && typeof window.customDeepAnalysisFunction === 'function') {
      console.log('[BondScore] Executing user-provided customDeepAnalysisFunction...');
      onProgress({ percent: 25, stage: 'Running custom search engine...', itemsFound: 0 });
      return await window.customDeepAnalysisFunction(cleanCurrent, cleanTarget, onProgress);
    }

    // Default internal search pipeline
    return await this._executeSearchPipeline(cleanCurrent, cleanTarget, searchQuery, onProgress, windowDays);
  }

  /**
   * Default execution pipeline using X's internal search query
   */
  async _executeSearchPipeline(currentUser, targetUser, query, onProgress, windowDays = 7) {
    const results = [];
    const now = Date.now();

    onProgress({ percent: 30, stage: 'Scanning conversation archives...', itemsFound: 0 });

    try {
      // 1. Try fetching via internal endpoint if cookies & CSRF are accessible
      const csrfToken = this._getCsrfToken();
      if (csrfToken) {
        onProgress({ percent: 50, stage: 'Querying X internal search timeline...', itemsFound: 0 });
        const apiEvents = await this._queryInternalApi(query, csrfToken, currentUser, targetUser, windowDays);
        if (apiEvents && apiEvents.scanCompleted) results.scanCompleted = true;
        if (apiEvents && apiEvents.length > 0) results.push(...apiEvents);
      }
    } catch (err) {
      console.warn('[BondScore] Internal search query failed, using DOM / heuristic fallback:', err);
    }

    // If API returned fewer or failed, query any visible on-page tweets/thread replies
    onProgress({ percent: 75, stage: 'Aggregating active thread records...', itemsFound: results.length });
    const domEvents = this._scrapeCurrentPageReplies(currentUser, targetUser);
    for (const evt of domEvents) {
      if (!results.some(r => r.tweetId && r.tweetId === evt.tweetId)) {
        results.push(evt);
      }
    }

    onProgress({ percent: 100, stage: results.length > 0 ? 'Deep analysis complete!' : 'No conversation records found.', itemsFound: results.length });
    return results;
  }

  _getCsrfToken() {
    const match = document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/);
    return match ? match[1] : null;
  }

  /**
   * Internal query to X Search timeline API
   */
  async _queryInternalApi(query, csrfToken, currentUser, targetUser, windowDays = 7) {
    try {
      const url = `https://x.com/i/api/2/search/adaptive.json?q=${encodeURIComponent(query)}&count=40&query_source=typed_query&pc=1&spelling_corrections=1`;
      const res = await fetch(url, {
        headers: {
          'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
          'x-csrf-token': csrfToken,
          'x-twitter-active-user': 'yes',
          'x-twitter-auth-type': 'OAuth2Session'
        },
        credentials: 'include'
      });

      if (!res.ok) return [];
      const json = await res.json();
      const events = [];
      const hasTweetCollection = !!(json && json.globalObjects && json.globalObjects.tweets && typeof json.globalObjects.tweets === 'object');
      if (!hasTweetCollection) return [];
      const tweets = json.globalObjects.tweets;
      const users = (json && json.globalObjects && json.globalObjects.users) ? json.globalObjects.users : {};
      const earliest = Date.now() - windowDays * 86400000;

      for (const [tweetId, tweet] of Object.entries(tweets)) {
        const author = users[tweet.user_id_str] || {};
        const authorHandle = (author.screen_name || tweet.user_screen_name || '').toLowerCase();
        const timestamp = new Date(tweet.created_at).getTime();
        if (!timestamp || timestamp < earliest) continue;
        if (authorHandle !== currentUser && authorHandle !== targetUser) continue;
        const text = tweet.full_text || '';
        const inReplyTo = tweet.in_reply_to_screen_name ? tweet.in_reply_to_screen_name.toLowerCase() : '';

        const direction = authorHandle === currentUser ? 'outbound' : 'inbound';
        const isReply = !!inReplyTo;
        const type = isReply
          ? (direction === 'outbound' ? 'reply_sent' : 'reply_received')
          : (tweet.is_quote_status ? 'quote' : 'mention');

        events.push({
          type,
          timestamp,
          tweetId: tweetId,
          textSnippet: text,
          direction,
          isMutual: false,
          isThread: isReply
        });
      }
      events.scanCompleted = true;
      return events;
    } catch (e) {
      return [];
    }
  }

  /**
   * Scrapes replies and exchanges currently loaded in DOM
   */
  _scrapeCurrentPageReplies(currentUser, targetUser) {
    const events = [];
    const tweetElements = document.querySelectorAll('article[data-testid="tweet"]');

    tweetElements.forEach((tweetEl) => {
      try {
        const textEl = tweetEl.querySelector('[data-testid="tweetText"]');
        const text = textEl ? textEl.innerText : '';
        const timeEl = tweetEl.querySelector('time');
        const timestamp = timeEl && timeEl.getAttribute('datetime')
          ? new Date(timeEl.getAttribute('datetime')).getTime()
          : Date.now();

        // Extract tweet link to get ID
        const link = tweetEl.querySelector('a[href*="/status/"]');
        const match = link ? link.getAttribute('href').match(/\/status\/(\d+)/) : null;
        const tweetId = match ? match[1] : `dom_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

        // Check author
        const userLinks = tweetEl.querySelectorAll('a[role="link"][href^="/"]');
        let authorHandle = '';
        for (const ul of userLinks) {
          const href = ul.getAttribute('href').replace(/^\//, '');
          if (href && !href.includes('/') && href !== 'home' && href !== 'explore') {
            authorHandle = href.toLowerCase();
            break;
          }
        }

        const isFromCurrent = authorHandle === currentUser;
        const isFromTarget = authorHandle === targetUser;

        if (isFromCurrent || isFromTarget) {
          const counterpart = isFromCurrent ? targetUser : currentUser;
          const fullText = tweetEl.innerText || text;
          const counterpartPattern = new RegExp(`@${counterpart}\\b`, 'i');
          if (!counterpartPattern.test(fullText)) return;
          const isReply = /Replying to\s+@/i.test(fullText);
          events.push({
            type: isReply ? (isFromCurrent ? 'reply_sent' : 'reply_received') : 'mention',
            timestamp,
            tweetId,
            textSnippet: text,
            isMutual: false,
            direction: isFromCurrent ? 'outbound' : 'inbound',
            isThread: isReply
          });
        }
      } catch (err) {
        // continue
      }
    });

    return events;
  }
}

/**
 * DeepAnalyzer Manager
 */
class DeepAnalyzerManager {
  constructor() {
    this.provider = new XSearchQueryAnalyzer();
    // Maps a handle to the in-flight analysis promise so duplicate requests
    // reuse the same result instead of warning and returning null.
    this.activeScans = new Map();
  }

  /**
   * Swap out or register a custom provider (e.g., Rezero Sanctuary method)
   * @param {BaseDeepProvider} customProvider
   */
  setProvider(customProvider) {
    if (customProvider && typeof customProvider.analyze === 'function') {
      this.provider = customProvider;
      console.log(`[BondScore] Active Deep Provider changed to: ${customProvider.name || 'Custom'}`);
    }
  }

  /**
   * Hook for user to inject raw function:
   * (currentUser, targetUser, onProgress) => Promise<Array<events>>
   */
  setCustomFunction(fn) {
    window.customDeepAnalysisFunction = fn;
    console.log('[BondScore] Custom deep analysis function registered successfully.');
  }

  /**
   * Performs deep analysis on a specific target user.
   */
  async runAnalysis(currentUser, targetUser, onProgress = () => {}, options = {}) {
    const cleanTarget = normalizeHandle(targetUser);
    if (!cleanTarget) return null;

    // Defensive: an older instance may still hold a Set from a previous build.
    if (!this.activeScans || typeof this.activeScans.has !== 'function') {
      this.activeScans = new Map();
    }

    // A second click (or an automatic profile scan) while an analysis is
    // running should wait for that same analysis, not fail with a warning.
    if (this.activeScans.has(cleanTarget)) {
      return await this.activeScans.get(cleanTarget);
    }

    const task = this._runAnalysisInternal(currentUser, cleanTarget, onProgress, options);
    this.activeScans.set(cleanTarget, task);
    try {
      return await task;
    } finally {
      this.activeScans.delete(cleanTarget);
    }
  }

  async _runAnalysisInternal(currentUser, cleanTarget, onProgress, options) {
    try {
      const events = await this.provider.analyze(currentUser, cleanTarget, onProgress, options);

      if (events && events.length > 0) {
        onProgress({ percent: 90, stage: 'Saving records to local storage...', itemsFound: events.length });

        for (const evt of events) {
          await window.bondStorage.recordInteraction(cleanTarget, evt);
        }

        // Increment deep scan stat
        const user = await window.bondStorage.getUser(cleanTarget);
        if (user) {
          user.stats = user.stats || {};
          user.stats.deepScans = (user.stats.deepScans || 0) + 1;
          await window.bondStorage.saveUser(cleanTarget, user);
        }
      }

      if (events && events.scanCompleted) {
        const user = (await window.bondStorage.getUser(cleanTarget)) || { handle: cleanTarget };
        user.historyBackfillAt = Date.now();
        await window.bondStorage.saveUser(cleanTarget, user);
      }

      onProgress({ percent: 100, stage: 'Ready!', itemsFound: Array.isArray(events) ? events.length : 0 });

      // Notify content script UI to update badges immediately
      window.dispatchEvent(new CustomEvent('bondscore:updated', { detail: { handle: cleanTarget } }));

      return await window.bondStorage.getUser(cleanTarget);
    } catch (err) {
      console.error(`[BondScore] Deep analysis failed for @${cleanTarget}:`, err);
      return null;
    }
  }

  /**
   * Looks up tweet interactions between ANY two handles (e.g. handleA and handleB)
   * and reports whether they have ever interacted via tweets, direction, and snippet history.
   */
  async lookupInteraction(handleA, handleB, onProgress = () => {}) {
    const cleanA = normalizeHandle(handleA);
    const cleanB = normalizeHandle(handleB);

    if (!cleanA || !cleanB) {
      throw new Error('Please enter two handles to check interactions.');
    }

    if (cleanA === cleanB) {
      throw new Error('Please enter two different handles.');
    }

    onProgress({ percent: 15, stage: `Searching tweets between @${cleanA} and @${cleanB}...`, itemsFound: 0 });

    let events = [];
    try {
      events = await this.provider.analyze(cleanA, cleanB, onProgress);
    } catch (e) {
      console.warn('[BondScore] Search query lookup notice:', e);
    }

    // Also check local storage records for any cached interactions involving either account
    if (window.bondStorage) {
      try {
        const localA = await window.bondStorage.getEvents(cleanA);
        const localB = await window.bondStorage.getEvents(cleanB);
        for (const evt of [...localA, ...localB]) {
          const text = (evt.textSnippet || '').toLowerCase();
          if (text.includes(`@${cleanA}`) || text.includes(`@${cleanB}`)) {
            if (!events.some(r => r.tweetId && r.tweetId === evt.tweetId)) {
              events.push(evt);
            }
          }
        }
      } catch (e) {}
    }

    // Sort by timestamp descending
    events.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

    const countAtoB = events.filter(e => e.type === 'reply_sent' || (e.textSnippet && e.textSnippet.toLowerCase().includes(`@${cleanB}`))).length;
    const countBtoA = events.filter(e => e.type === 'reply_received' || (e.textSnippet && e.textSnippet.toLowerCase().includes(`@${cleanA}`))).length;
    const hasInteracted = events.length > 0;

    const query = `(from:${cleanA} to:${cleanB}) OR (from:${cleanB} to:${cleanA})`;
    const searchUrl = `https://x.com/search?q=${encodeURIComponent(query)}&f=live`;

    onProgress({
      percent: 100,
      stage: hasInteracted ? `Found ${events.length} interaction(s)!` : 'No tweet interactions found.',
      itemsFound: events.length
    });

    return {
      handleA: cleanA,
      handleB: cleanB,
      hasInteracted,
      totalCount: events.length,
      countAtoB,
      countBtoA,
      events,
      lastInteraction: events[0] ? events[0].timestamp : null,
      searchUrl
    };
  }
}

window.deepAnalyzer = new DeepAnalyzerManager();
window.BaseDeepProvider = BaseDeepProvider;
