/**
 * BondScore - Service Worker (Background)
 * Manages daily time-decay recalculations and extension lifecycle.
 */

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[BondScore] Extension installed/updated:', details.reason);

  // Set default settings if not already present
  chrome.storage.local.get(['settings'], (res) => {
    if (!res.settings) {
      chrome.storage.local.set({
        settings: {
          platforms: {
            x: { enabled: true, timeline: true, dms: true },
            threads: { enabled: false, timeline: true, dms: true },
            bluesky: { enabled: false, timeline: true, dms: true }
          },
          decayHalfLifeDays: 14,
          gracePeriodDays: 5,
          weights: {
            mutualReply: 15,
            replySent: 8,
            replyReceived: 8,
            quote: 6,
            mention: 5,
            like: 2,
            deepSyncExchange: 10
          },
          showBadgesOnTimeline: true,
          showBadgesOnProfiles: true,
          showBadgesOnReplies: true,
          showStreaks: true,
          badgeStyle: 'subtle',
          minScoreToShowBadge: 1
        }
      });
    }
  });

  // Schedule periodic decay check every 12 hours
  if (chrome.alarms) {
    chrome.alarms.create('bondscore-decay-check', {
      periodInMinutes: 720
    });
  }
});

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'bondscore-decay-check') {
      await performDecayRecalculation();
    }
  });
}

/**
 * Recalculates time-decay for all tracked users from the local event ledger.
 */
async function performDecayRecalculation() {
  chrome.storage.local.get(null, async (allData) => {
    if (!allData) return;

    const settings = allData.settings || {};
    const halfLifeDays = settings.decayHalfLifeDays || 14;
    const gracePeriodDays = settings.gracePeriodDays ?? 5;
    const weights = Object.assign({
      mutualReply: 15,
      replySent: 8,
      replyReceived: 8,
      quote: 6,
      mention: 5,
      like: 2,
      deepSyncExchange: 10
    }, settings.weights || {});

    const lambda = Math.LN2 / halfLifeDays;
    const msInDay = 86400000;
    const now = Date.now();
    const updates = {};

    for (const [key, user] of Object.entries(allData)) {
      let isUserRecord = false;
      let eventsKey = '';

      if (key.startsWith('user:') && user && user.handle) {
        isUserRecord = true;
        eventsKey = `events:${user.handle}`;
      } else if (key.startsWith('acc:') && key.includes(':user:') && user && user.handle) {
        // Multi-account scoped keys: acc:<account>:user:<handle> -> acc:<account>:events:<handle>
        isUserRecord = true;
        eventsKey = key.replace(':user:', ':events:');
      }

      if (!isUserRecord) continue;
      const events = allData[eventsKey] || [];
      if (events.length === 0) continue;

      let accumulatedRaw = 0;
      let sentCount = 0;
      let receivedCount = 0;
      let likeCount = 0;

      for (const evt of events) {
        const inbound = evt.direction === 'inbound' || ['reply_received', 'dm_received', 'mention', 'signal_follow_back', 'deep_sync'].includes(evt.type);
        let baseWeight = 0;
        switch (evt.type) {
          case 'reply_mutual': baseWeight = weights.mutualReply; sentCount++; receivedCount++; break;
          case 'reply_thread': baseWeight = 16; inbound ? receivedCount++ : sentCount++; break;
          case 'reply_sent': baseWeight = weights.replySent; inbound ? receivedCount++ : sentCount++; break;
          case 'reply_received': baseWeight = weights.replyReceived; inbound ? receivedCount++ : sentCount++; break;
          case 'dm_mutual': baseWeight = weights.dmMutual || 20; sentCount++; receivedCount++; break;
          case 'dm_sent': baseWeight = weights.dmSent || 12; inbound ? receivedCount++ : sentCount++; break;
          case 'dm_received': baseWeight = weights.dmReceived || 12; inbound ? receivedCount++ : sentCount++; break;
          case 'signal_follow_back':
          case 'signal_mutual_follow': baseWeight = 16; sentCount++; receivedCount++; break;
          case 'signal_you_followed': baseWeight = 5; sentCount++; break;
          case 'signal_unfollowed':
          case 'signal_blocked':
          case 'signal_you_unfollowed': baseWeight = 0; break;
          case 'quote': baseWeight = weights.quote; inbound ? receivedCount++ : sentCount++; break;
          case 'mention': baseWeight = weights.mention; inbound ? receivedCount++ : sentCount++; break;
          case 'like':
            likeCount++;
            baseWeight = likeCount <= 3 ? weights.like : Math.max(0.4, weights.like / Math.sqrt(likeCount - 2));
            inbound ? receivedCount++ : sentCount++;
            break;
          case 'deep_sync': baseWeight = weights.deepSyncExchange; receivedCount++; break;
          default: baseWeight = evt.weight || 2; inbound ? receivedCount++ : sentCount++;
        }

        if (evt.isThread || evt.type === 'reply_thread') baseWeight *= 1.35;
        if (evt.isMutual) baseWeight *= 1.3;

        const ageMs = Math.max(0, now - evt.timestamp);
        const ageDays = ageMs / msInDay;
        const recencyBoost = ageDays <= 1 ? 1.5 : ageDays <= 3 ? 1.3 : ageDays <= 7 ? 1.15 : 1;
        const decayableDays = Math.max(0, ageDays - gracePeriodDays);
        accumulatedRaw += baseWeight * recencyBoost * Math.exp(-lambda * decayableDays);
      }

      if (sentCount > 0 && receivedCount > 0) {
        const balance = Math.min(sentCount, receivedCount) / Math.max(sentCount, receivedCount);
        accumulatedRaw *= 1.3 + 0.3 * balance;
      } else if (sentCount >= 4 && receivedCount === 0) {
        accumulatedRaw = Math.min(accumulatedRaw, 16);
      }

        const K = 45;
        const normalized = 100 * (1 - Math.exp(-accumulatedRaw / K));
        const newScore = Math.round(Math.min(100, Math.max(0, normalized)) * 10) / 10;

        if (Math.abs(newScore - (user.currentScore || 0)) >= 0.1) {
          user.trend = newScore > user.currentScore ? 'rising' : (newScore < user.currentScore ? 'decaying' : 'steady');
          user.currentScore = newScore;
          if (newScore >= 90) user.tier = 'soulmates';
          else if (newScore >= 70) user.tier = 'close_friends';
          else if (newScore >= 40) user.tier = 'conversant';
          else if (newScore >= 15) user.tier = 'acquaintance';
          else user.tier = 'dormant';

          user.lastCalculated = now;
          updates[key] = user;
        }
      }

    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
      console.log(`[BondScore] Periodic decay check updated ${Object.keys(updates).length} accounts.`);
    }
  });
}
