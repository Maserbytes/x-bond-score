/**
 * BondScore for X - Extension Popup Logic (v1.2 - Pro Design System)
 * Controls leaderboard, filter pills, solar system orbit view, graphic exporter,
 * dynamic theme switcher (system auto, dark, light), settings, and CRM analytics.
 */

let cachedUsers = [];
let currentFilter = 'all';
let currentPlatformFilter = 'all'; // 'all' | 'x' | 'threads' | 'bsky'
let currentUsername = 'you';
let currentTheme = 'system'; // 'system' | 'dark' | 'light'
let leaderboardRefreshTimer = null;
let leaderboardLoadGeneration = 0;
let orbitRenderTimer = null;

function shouldRefreshDashboardForStorageChanges(changes, activeAccount) {
  if (!changes || typeof changes !== 'object') return false;
  if (changes.currentUser || changes.knownAccounts || changes.accountsMetadata) return true;

  const account = (activeAccount || '').replace(/^@/, '').toLowerCase().trim();
  const prefix = account ? `acc:${account}:` : '';
  return Object.keys(changes).some((key) => account
    ? key.startsWith(`${prefix}user:`) || key.startsWith(`${prefix}events:`) || key.startsWith(`${prefix}dm:`)
    : key.startsWith('user:') || key.startsWith('events:') || key.startsWith('dm:'));
}

function queueDashboardRefresh() {
  if (leaderboardRefreshTimer) clearTimeout(leaderboardRefreshTimer);
  leaderboardRefreshTimer = setTimeout(async () => {
    leaderboardRefreshTimer = null;
    await loadLeaderboard();

    const activeTab = document.querySelector('.tab-btn.active');
    if (activeTab && activeTab.dataset.tab === 'tab-orbit') renderOrbitCanvas();
    else if (activeTab && activeTab.dataset.tab === 'tab-radar') renderRadarTab();
    else if (activeTab && activeTab.dataset.tab === 'tab-dms') renderDmsTab();
  }, 100);
}

function queueOrbitCanvasRender() {
  if (orbitRenderTimer) clearTimeout(orbitRenderTimer);
  orbitRenderTimer = setTimeout(() => {
    orbitRenderTimer = null;
    const canvas = document.getElementById('orbit-canvas');
    const activeTab = document.querySelector('.tab-btn.active');
    if (canvas && canvas.offsetParent !== null && activeTab && activeTab.dataset.tab === 'tab-orbit') {
      renderOrbitCanvas();
    }
  }, 60);
}

function isLightMode() {
  const dataTheme = document.documentElement.getAttribute('data-theme');
  if (dataTheme === 'light') return true;
  if (dataTheme === 'dark') return false;
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
}

function applyTheme(theme) {
  currentTheme = theme || 'system';
  const root = document.documentElement;

  if (theme === 'dark') {
    root.setAttribute('data-theme', 'dark');
  } else if (theme === 'light') {
    root.setAttribute('data-theme', 'light');
  } else {
    root.removeAttribute('data-theme');
  }

  // Update header toggle button
  const iconAuto = document.getElementById('theme-icon-auto');
  const iconDark = document.getElementById('theme-icon-dark');
  const iconLight = document.getElementById('theme-icon-light');
  const label = document.getElementById('theme-toggle-label');
  const toggleBtn = document.getElementById('theme-toggle-btn');

  if (iconAuto && iconDark && iconLight) {
    iconAuto.style.display = currentTheme === 'system' ? 'inline-block' : 'none';
    iconDark.style.display = currentTheme === 'dark' ? 'inline-block' : 'none';
    iconLight.style.display = currentTheme === 'light' ? 'inline-block' : 'none';
  }
  if (label) {
    label.innerText = currentTheme === 'system' ? 'Auto' : currentTheme === 'dark' ? 'Dark' : 'Light';
  }
  if (toggleBtn) {
    const isDarkNow = !isLightMode();
    toggleBtn.title = `Theme: ${currentTheme.toUpperCase()} (${isDarkNow ? 'Dark' : 'Light'} active). Click to toggle.`;
  }

  // Update Settings segmented buttons
  const segBtns = document.querySelectorAll('.theme-seg-btn');
  segBtns.forEach(b => {
    b.classList.toggle('active', b.getAttribute('data-theme') === currentTheme);
  });

  // Re-render canvas if on orbit tab
  const activeTab = document.querySelector('.tab-btn.active');
  if (activeTab && activeTab.dataset.tab === 'tab-orbit') {
    renderOrbitCanvas();
  }
}

async function setThemeAndSave(theme) {
  applyTheme(theme);
  await window.bondStorage.updateSettings({ theme });
}

function setupTheme(initialTheme = 'system') {
  applyTheme(initialTheme);

  const toggleBtn = document.getElementById('theme-toggle-btn');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      let nextTheme = 'dark';
      if (currentTheme === 'system') nextTheme = 'dark';
      else if (currentTheme === 'dark') nextTheme = 'light';
      else if (currentTheme === 'light') nextTheme = 'system';
      await setThemeAndSave(nextTheme);
    });
  }

  // OS preference change listener
  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (currentTheme === 'system') {
        applyTheme('system');
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  await window.bondStorage.init();

  const settings = await window.bondStorage.getSettings();
  setupTheme(settings.theme || 'system');

  // Tab Navigation
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabPanes.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const target = document.getElementById(btn.dataset.tab);
      if (target) {
        target.classList.add('active');
        if (btn.dataset.tab === 'tab-orbit') {
          renderOrbitCanvas();
        } else if (btn.dataset.tab === 'tab-radar') {
          renderRadarTab();
        } else if (btn.dataset.tab === 'tab-dms') {
          renderDmsTab();
        }
      }
    });
  });

  // Load Initial State
  await setupAccountSwitcher();
  await syncActiveTabAccountIfAvailable();
  await loadLeaderboard();
  await loadSettingsForm();
  renderRadarTab();
  setupPlatformFilterPills();
  setupFilterPills();
  setupSearchHandler();
  setupDmFilterPills();
  setupDmSearchHandler();
  setupOrbitExporter();
  setupTwoHandleLookup();

  // Storage change listener to keep popup in sync live with browser actions
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local') return;

      const accountMetadataChanged = !!(changes.currentUser || changes.knownAccounts || changes.accountsMetadata);
      if (accountMetadataChanged) void setupAccountSwitcher();

      const activeAccount = window.bondStorage.currentUser || (currentUsername === 'you' ? '' : currentUsername);
      if (shouldRefreshDashboardForStorageChanges(changes, activeAccount)) {
        queueDashboardRefresh();
      }
    });
  }
});

/**
 * Sets up the multi-account dropdown switcher in the popup header.
 * Allows viewing separate scores and interaction CRM per account.
 */
async function setupAccountSwitcher() {
  const selectorBtn = document.getElementById('account-selector-btn');
  const dropdown = document.getElementById('account-dropdown');
  const listEl = document.getElementById('account-dropdown-list');
  const countEl = document.getElementById('account-dropdown-count');
  const handleTextEl = document.getElementById('account-handle-text');
  const avatarMiniEl = document.getElementById('account-avatar-mini');

  if (!selectorBtn || !dropdown || !listEl) return;

  const { activeAccount, accounts } = await window.bondStorage.getKnownAccounts();
  const currentAcc = activeAccount || 'you';
  currentUsername = currentAcc;

  // Update header button text and avatar
  if (handleTextEl) {
    handleTextEl.innerText = activeAccount ? `@${activeAccount}` : 'Browse X';
  }
  if (avatarMiniEl) {
    const activeMeta = accounts.find(a => a.handle === activeAccount);
    if (activeMeta && activeMeta.avatarUrl) {
      avatarMiniEl.innerHTML = `<img src="${activeMeta.avatarUrl}" alt="${activeAccount}">`;
    } else {
      avatarMiniEl.innerText = activeAccount ? activeAccount.charAt(0).toUpperCase() : '👤';
    }
  }

  // Populate dropdown list
  if (countEl) {
    countEl.innerText = `${accounts.length} ${accounts.length === 1 ? 'account' : 'accounts'}`;
  }

  listEl.innerHTML = '';
  if (accounts.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'account-dropdown-item active';
    empty.innerHTML = `
      <div class="account-item-left">
        <div class="account-item-avatar">👤</div>
        <div class="account-item-names">
          <span class="account-item-display">Current Session</span>
          <span class="account-item-handle">Browse X to detect</span>
        </div>
      </div>
      <span class="account-item-check">✓</span>
    `;
    listEl.appendChild(empty);
  } else {
    accounts.forEach(acc => {
      const item = document.createElement('div');
      item.className = `account-dropdown-item ${acc.isActive ? 'active' : ''}`;
      item.innerHTML = `
        <div class="account-item-left">
          <div class="account-item-avatar">
            ${acc.avatarUrl ? `<img src="${acc.avatarUrl}" alt="${acc.handle}">` : acc.handle.charAt(0).toUpperCase()}
          </div>
          <div class="account-item-names">
            <span class="account-item-display">${acc.displayName || acc.handle}</span>
            <span class="account-item-handle">@${acc.handle}</span>
          </div>
        </div>
        ${acc.isActive ? `<span class="account-item-check">✓</span>` : ''}
      `;

      item.addEventListener('click', async (e) => {
        e.stopPropagation();
        dropdown.style.display = 'none';
        selectorBtn.classList.remove('open');
        selectorBtn.setAttribute('aria-expanded', 'false');

        if (!acc.isActive) {
          await window.bondStorage.switchAccount(acc.handle);
          await setupAccountSwitcher();
          await loadLeaderboard();
          const activeTab = document.querySelector('.tab-btn.active');
          if (activeTab && activeTab.dataset.tab === 'tab-orbit') {
            renderOrbitCanvas();
          } else if (activeTab && activeTab.dataset.tab === 'tab-radar') {
            renderRadarTab();
          }
        }
      });

      listEl.appendChild(item);
    });
  }

  // Dropdown toggle logic
  selectorBtn.onclick = (e) => {
    e.stopPropagation();
    const isOpen = dropdown.style.display !== 'none';
    if (isOpen) {
      dropdown.style.display = 'none';
      selectorBtn.classList.remove('open');
      selectorBtn.setAttribute('aria-expanded', 'false');
    } else {
      dropdown.style.display = 'block';
      selectorBtn.classList.add('open');
      selectorBtn.setAttribute('aria-expanded', 'true');
    }
  };

  // Close dropdown on click outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#account-bar')) {
      dropdown.style.display = 'none';
      selectorBtn.classList.remove('open');
      selectorBtn.setAttribute('aria-expanded', 'false');
    }
  });
}

/**
 * Checks if active browser tab is on X and auto-detects account on initial run.
 * Preserves user account selection once established to avoid asynchronous race overrides.
 */
async function syncActiveTabAccountIfAvailable() {
  const currentStored = await window.bondStorage.getCurrentUser();
  if (currentStored) return;

  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].url && (tabs[0].url.includes('x.com') || tabs[0].url.includes('twitter.com'))) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'bondscore:get_active_account' }, async (response) => {
            if (response && response.handle) {
              const freshStored = await window.bondStorage.getCurrentUser();
              if (!freshStored) {
                await window.bondStorage.switchAccount(response.handle, response.metadata);
                await setupAccountSwitcher();
                await loadLeaderboard();
                const activeTab = document.querySelector('.tab-btn.active');
                if (activeTab && activeTab.dataset.tab === 'tab-orbit') renderOrbitCanvas();
                else if (activeTab && activeTab.dataset.tab === 'tab-radar') renderRadarTab();
              }
            }
          });
        }
      });
    } catch (e) {}
  }
}

async function loadCurrentUserTag() {
  const userTag = document.getElementById('current-user-tag');
  const currentUser = await window.bondStorage.getCurrentUser();
  if (currentUser) {
    currentUsername = currentUser;
    if (userTag) userTag.innerText = `@${currentUser}`;
  } else {
    if (userTag) userTag.innerText = 'Browse X to auto-detect';
  }
}

async function loadLeaderboard() {
  const loadGeneration = ++leaderboardLoadGeneration;
  const totalAccountsEl = document.getElementById('stat-total-accounts');
  const topScoreEl = document.getElementById('stat-top-score');
  const mutualRepliesEl = document.getElementById('stat-mutual-replies');

  const users = await window.bondStorage.getAllUsers(null, currentPlatformFilter);
  if (loadGeneration !== leaderboardLoadGeneration) return;
  cachedUsers = users;
  totalAccountsEl.innerText = cachedUsers.length;

  let maxScore = 0;
  let totalMutual = 0;

  for (const u of cachedUsers) {
    if ((u.currentScore || 0) > maxScore) maxScore = Math.round(u.currentScore);
    totalMutual += (u.stats && u.stats.mutualExchanges) || 0;
  }

  topScoreEl.innerText = maxScore;
  mutualRepliesEl.innerText = totalMutual;

  applyFilterAndRender();
}

function setupFilterPills() {
  const pills = document.querySelectorAll('.filter-pill');
  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentFilter = pill.dataset.filter;
      applyFilterAndRender();
    });
  });
}

function setupPlatformFilterPills() {
  const pills = document.querySelectorAll('.platform-pill');
  pills.forEach((pill) => {
    pill.addEventListener('click', async () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentPlatformFilter = pill.dataset.platform || 'all';
      await loadLeaderboard();
      await renderDmsTab();
      renderRadarTab();
    });
  });
}

function getCRMStatusForUser(u) {
  if (u.crmStatusData) return u.crmStatusData;
  const sSent = (u.stats && ((u.stats.repliesSent || 0) + (u.stats.dmsSent || 0) + (u.stats.likesSent ?? u.stats.likes ?? 0) + (u.stats.quotesSent || 0) + (u.stats.mentionsSent || 0))) || 0;
  const sRecv = (u.stats && ((u.stats.repliesReceived || 0) + (u.stats.dmsReceived || 0) + (u.stats.likesReceived || 0) + (u.stats.quotesReceived || 0) + (u.stats.mentionsReceived || 0))) || 0;
  return BondScoring.calculateCRMStatus(u.currentScore || 0, sSent, sRecv, u.streakDays || 0);
}

function applyFilterAndRender() {
  const q = (document.getElementById('mutual-search-input').value || '').toLowerCase().trim();
  let list = cachedUsers;

  if (currentFilter === 'vip') {
    list = list.filter(u => u.isPinned);
  } else if (currentFilter === 'streaks') {
    list = list.filter(u => (u.streakDays || 0) > 1);
  } else if (currentFilter === 'at-risk') {
    list = list.filter(u => {
      const daysSince = (Date.now() - (u.lastInteraction || Date.now())) / (1000 * 60 * 60 * 24);
      return daysSince >= 3 && (u.currentScore || 0) >= 20;
    });
  } else if (currentFilter === 'supporters') {
    list = list.filter(u => {
      const s = ((u.stats && u.stats.repliesSent) || 0) + ((u.stats && u.stats.dmsSent) || 0) + (u.stats && (u.stats.likesSent ?? u.stats.likes) || 0) + ((u.stats && u.stats.quotesSent) || 0) + ((u.stats && u.stats.mentionsSent) || 0);
      const r = ((u.stats && u.stats.repliesReceived) || 0) + ((u.stats && u.stats.dmsReceived) || 0) + ((u.stats && u.stats.likesReceived) || 0) + ((u.stats && u.stats.quotesReceived) || 0) + ((u.stats && u.stats.mentionsReceived) || 0);
      return r > 0 && (r >= s || r >= 2);
    });
  } else if (currentFilter === 'dormant') {
    const now = Date.now();
    list = list.filter(u => {
      const days = Math.floor((now - (u.lastInteraction || now)) / 86400000);
      const s = ((u.stats && u.stats.repliesSent) || 0) + ((u.stats && u.stats.dmsSent) || 0) + (u.stats && (u.stats.likesSent ?? u.stats.likes) || 0) + ((u.stats && u.stats.quotesSent) || 0) + ((u.stats && u.stats.mentionsSent) || 0);
      const r = ((u.stats && u.stats.repliesReceived) || 0) + ((u.stats && u.stats.dmsReceived) || 0) + ((u.stats && u.stats.likesReceived) || 0) + ((u.stats && u.stats.quotesReceived) || 0) + ((u.stats && u.stats.mentionsReceived) || 0);
      return days >= 14 && ((u.currentScore || 0) > 5 || (s + r) > 0);
    });
  } else if (currentFilter === 'besties') {
    list = list.filter(u => getCRMStatusForUser(u).id === 'besties');
  } else if (currentFilter === 'mutuals') {
    list = list.filter(u => {
      const cId = getCRMStatusForUser(u).id;
      return cId === 'mutuals' || cId === 'besties';
    });
  } else if (currentFilter === 'one-sided') {
    list = list.filter(u => {
      const cId = getCRMStatusForUser(u).id;
      return cId === 'one_sided' || cId === 'one_sided_them';
    });
  } else if (currentFilter === 'signals') {
    list = list.filter(u => u.signals && (u.signals.isBlocked || u.signals.isMutual || u.signals.theyFollowYou || u.signals.youFollowThem));
  } else if (currentFilter === 'stranger') {
    list = list.filter(u => {
      const cId = getCRMStatusForUser(u).id;
      return cId === 'stranger' || cId === 'casual';
    });
  }

  if (q) {
    list = list.filter(u =>
      (u.handle && u.handle.toLowerCase().includes(q)) ||
      (u.displayName && u.displayName.toLowerCase().includes(q))
    );
  }

  renderUserList(list);
}

function renderUserList(users) {
  const listEl = document.getElementById('mutuals-list');
  listEl.innerHTML = '';

  if (!users || users.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🤝</div>
        <h3>No mutuals match</h3>
        <p>${currentFilter === 'all' ? 'Browse X, reply to mutuals, or run <strong>Deep Analysis</strong> on any profile to calculate your first Bond Score.' : 'No contacts found matching this filter.'}</p>
      </div>
    `;
    return;
  }

  users.forEach((u) => {
    const tier = BondScoring.getTier(u.currentScore);
    const scoreVal = Math.round(u.currentScore || 0);
    const isPinned = !!u.isPinned;
    const crm = getCRMStatusForUser(u);
    const dmsTotal = ((u.stats && u.stats.dmsSent) || 0) + ((u.stats && u.stats.dmsReceived) || 0);
    const plat = u.platform || 'x';
    const platIcon = plat === 'threads' ? '🧵' : (plat === 'bsky' ? '🦋' : '𝕏');
    const platTitle = plat === 'threads' ? 'Threads' : (plat === 'bsky' ? 'Bluesky' : 'X (Twitter)');

    const item = document.createElement('div');
    item.className = 'mutual-item';

    let signalHtml = '';
    const followRel = typeof BondScoring !== 'undefined' && BondScoring.getFollowRelationship
      ? BondScoring.getFollowRelationship(u.signals)
      : null;
    if (followRel) {
      signalHtml = `<span class="popup-signal-pill ${followRel.id}" title="${followRel.desc}">${followRel.badgeText}</span>`;
    }

    item.innerHTML = `
      <div class="mutual-user-info">
        <div class="mutual-avatar-wrap">
          ${u.avatarUrl
            ? `<img class="mutual-avatar" src="${escapeHtml(u.avatarUrl)}" alt="${escapeHtml(u.displayName || u.handle)}">`
            : `<div class="mutual-avatar-fallback">${escapeHtml((u.handle || 'X').charAt(0).toUpperCase())}</div>`
          }
          ${isPinned ? `<span class="mutual-pin-badge">⭐</span>` : ''}
        </div>
        <div class="mutual-names">
          <div class="mutual-name-row">
            <span class="mutual-plat-pill plat-${plat}" title="${platTitle}">${platIcon}</span>
            <span class="mutual-name">${escapeHtml(u.displayName || u.handle)}</span>
            <span class="popup-crm-pill ${crm.id}" title="${crm.desc}">${crm.emoji} ${crm.label}</span>
            ${signalHtml}
            ${(u.streakDays || 0) > 1 ? `<span class="mutual-streak-badge">🔥${u.streakDays}d</span>` : ''}
          </div>
          <div class="mutual-handle-sub">
            <span>@${escapeHtml(u.handle)}</span>
            ${dmsTotal > 0 ? `<span class="mutual-dm-count" title="${dmsTotal} direct messages tracked">✉️ ${dmsTotal} DMs</span>` : ''}
            ${u.note ? `<span class="mutual-note-snippet" title="${escapeHtml(u.note)}">📝 ${escapeHtml(u.note)}</span>` : ''}
          </div>
        </div>
      </div>
      <div class="mutual-right-col">
        <button class="quick-pin-btn ${isPinned ? 'pinned' : ''}" title="${isPinned ? 'Unpin VIP' : 'Pin as VIP'}">⭐</button>
        <div class="mutual-score-badge" style="background: ${tier.bg}; color: ${tier.color}; border: 1px solid ${tier.color}40">
          <span>${tier.emoji}</span>
          <strong>${scoreVal}</strong>
        </div>
      </div>
    `;

    // Click pin button to toggle VIP
    const pinBtn = item.querySelector('.quick-pin-btn');
    pinBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const newPinned = await window.bondStorage.togglePin(u.handle);
      u.isPinned = newPinned;
      await loadLeaderboard();
    });

    // Click card to open X profile in new tab
    item.addEventListener('click', () => {
      chrome.tabs.create({ url: `https://x.com/${u.handle}` });
    });

    listEl.appendChild(item);
  });
}

function setupSearchHandler() {
  const searchInput = document.getElementById('mutual-search-input');
  searchInput.addEventListener('input', () => {
    applyFilterAndRender();
  });
}

/**
 * 🪐 Mutuals Orbit Canvas Rendering (Solar System)
 */
function renderOrbitCanvas() {
  const canvas = document.getElementById('orbit-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const w = canvas.width;
  const h = canvas.height;
  const centerX = w / 2;
  const centerY = h / 2;

  const isLight = isLightMode();

  // Clear & Canvas Background
  ctx.fillStyle = isLight ? '#f8fafc' : '#05070a';
  ctx.fillRect(0, 0, w, h);

  if (!isLight) {
    // Background stars for dark mode
    drawStarfield(ctx, w, h, 60);
  } else {
    // Subtle constellation grid dots for light mode
    drawLightGrid(ctx, w, h);
  }

  // Orbit Radii
  const rCore = 52;
  const rClose = 100;
  const rCasual = 150;

  // Draw concentric orbit tracks
  drawOrbitRing(ctx, centerX, centerY, rCasual, '#794bc4', 'Mutuals & Acquaintances (1-34)');
  drawOrbitRing(ctx, centerX, centerY, rClose, '#1d9bf0', 'Close Conversants (35-69)');
  drawOrbitRing(ctx, centerX, centerY, rCore, '#f91880', 'Core Bonds (70+)');

  // Draw Sun / Center User
  drawCenterSun(ctx, centerX, centerY, currentUsername);

  // Group mutuals by inclusive tier rings - all tracked mutuals appear and persist!
  const coreUsers = cachedUsers.filter(u => (u.currentScore || 0) >= 70);
  const closeUsers = cachedUsers.filter(u => (u.currentScore || 0) >= 35 && (u.currentScore || 0) < 70);
  const casualUsers = cachedUsers.filter(u => (u.currentScore || 0) < 35);

  distributePlanetsOnRing(ctx, coreUsers, centerX, centerY, rCore, '#f91880');
  distributePlanetsOnRing(ctx, closeUsers, centerX, centerY, rClose, '#1d9bf0');
  distributePlanetsOnRing(ctx, casualUsers, centerX, centerY, rCasual, '#794bc4');

  // If no mutuals, draw empty state tip
  if (cachedUsers.length === 0) {
    ctx.fillStyle = isLight ? '#64748b' : '#71767b';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Interact with accounts on X to populate your orbit', centerX, centerY + 90);
  }
}

function drawLightGrid(ctx, w, h) {
  ctx.save();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
  for (let x = 15; x < w; x += 26) {
    for (let y = 15; y < h; y += 26) {
      ctx.fillRect(x, y, 1.5, 1.5);
    }
  }
  ctx.restore();
}

function drawStarfield(ctx, w, h, count) {
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < count; i++) {
    const x = (Math.sin(i * 997) * 0.5 + 0.5) * w;
    const y = (Math.cos(i * 613) * 0.5 + 0.5) * h;
    const size = (i % 3 === 0) ? 1.5 : 0.8;
    const alpha = 0.2 + (i % 5) * 0.15;
    ctx.globalAlpha = alpha;
    ctx.fillRect(x, y, size, size);
  }
  ctx.globalAlpha = 1.0;
}

function drawOrbitRing(ctx, cx, cy, radius, color, label) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.strokeStyle = color;
  ctx.globalAlpha = isLightMode() ? 0.38 : 0.25;
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  ctx.stroke();
  ctx.restore();
}

function drawCenterSun(ctx, cx, cy, username) {
  ctx.save();

  // Outer glow
  const grad = ctx.createRadialGradient(cx, cy, 6, cx, cy, 26);
  grad.addColorStop(0, '#ffd400');
  grad.addColorStop(0.5, 'rgba(255, 122, 0, 0.4)');
  grad.addColorStop(1, 'rgba(255, 122, 0, 0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, 26, 0, Math.PI * 2);
  ctx.fill();

  // Core sphere
  ctx.fillStyle = '#ff7a00';
  ctx.beginPath();
  ctx.arc(cx, cy, 14, 0, Math.PI * 2);
  ctx.fill();

  // Text
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 9px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('YOU', cx, cy);

  ctx.restore();
}

// Cache loaded avatar images for instant canvas rendering
const pfpCache = new Map();

function getLoadedPfp(url, onLoadedCallback) {
  if (!url) return null;
  if (pfpCache.has(url)) {
    const img = pfpCache.get(url);
    return (img.complete && img.naturalWidth > 0) ? img : null;
  }
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.src = url;
  img.onload = () => {
    if (onLoadedCallback) onLoadedCallback();
  };
  pfpCache.set(url, img);
  return null;
}

function distributePlanetsOnRing(ctx, users, cx, cy, radius, color) {
  if (!users || users.length === 0) return;
  const count = users.length;
  const angleStep = (Math.PI * 2) / count;
  const offset = radius * 0.1;
  const pfpRadius = 13; // 26px diameter for clear avatar visibility

  users.forEach((u, i) => {
    const angle = i * angleStep + offset;
    const px = cx + Math.cos(angle) * radius;
    const py = cy + Math.sin(angle) * radius;

    ctx.save();

    // 1. Accent border ring in tier color
    ctx.beginPath();
    ctx.arc(px, py, pfpRadius + 1.5, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();

    // 2. Profile Picture (PFP) or initial fallback
    const pfp = getLoadedPfp(u.avatarUrl, () => {
      queueOrbitCanvasRender();
    });

    if (pfp) {
      // Draw circular clipped avatar PFP
      ctx.save();
      ctx.beginPath();
      ctx.arc(px, py, pfpRadius, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(pfp, px - pfpRadius, py - pfpRadius, pfpRadius * 2, pfpRadius * 2);
      ctx.restore();
    } else {
      // Fallback: planet with colored initial
      ctx.beginPath();
      ctx.arc(px, py, pfpRadius, 0, Math.PI * 2);
      ctx.fillStyle = isLightMode() ? '#e2e8f0' : '#16181c';
      ctx.fill();

      ctx.fillStyle = color;
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const initial = (u.displayName || u.handle || 'X').charAt(0).toUpperCase();
      ctx.fillText(initial, px, py);
    }

    // 3. Planet handle & score pill
    ctx.font = 'bold 9px sans-serif';
    ctx.fillStyle = isLightMode() ? '#0f172a' : '#ffffff';
    ctx.textAlign = 'center';
    const labelY = py > cy ? py + pfpRadius + 11 : py - pfpRadius - 4;
    ctx.fillText(`@${u.handle.slice(0, 9)} (${Math.round(u.currentScore || 0)})`, px, labelY);

    ctx.restore();
  });
}

/**
 * 📸 Export High-Res Orbit Graphic
 */
function setupOrbitExporter() {
  const btn = document.getElementById('orbit-download-btn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    btn.innerText = 'Exporting...';

    // Create 1000x1000 high-res offscreen canvas
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = 1000;
    exportCanvas.height = 1000;
    const ctx = exportCanvas.getContext('2d');

    const w = 1000;
    const h = 1000;
    const cx = 500;
    const cy = 520;

    // Rich Dark Cosmic Background
    const bgGrad = ctx.createRadialGradient(cx, cy, 100, cx, cy, 600);
    bgGrad.addColorStop(0, '#0d131f');
    bgGrad.addColorStop(1, '#020305');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Starfield
    drawStarfield(ctx, w, h, 200);

    // Header Title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 36px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🪐 X MUTUALS ORBIT', cx, 80);

    ctx.font = '20px sans-serif';
    ctx.fillStyle = '#1d9bf0';
    ctx.fillText(`Gravitational center: @${currentUsername}`, cx, 115);

    // Radii
    const rCore = 140;
    const rClose = 260;
    const rCasual = 380;

    drawOrbitRing(ctx, cx, cy, rCasual, '#794bc4', 'Mutuals & Acquaintances');
    drawOrbitRing(ctx, cx, cy, rClose, '#1d9bf0', 'Close Conversants');
    drawOrbitRing(ctx, cx, cy, rCore, '#f91880', 'Core Bonds');

    // Sun
    ctx.save();
    const sunGrad = ctx.createRadialGradient(cx, cy, 15, cx, cy, 60);
    sunGrad.addColorStop(0, '#ffd400');
    sunGrad.addColorStop(0.5, 'rgba(255, 122, 0, 0.4)');
    sunGrad.addColorStop(1, 'rgba(255, 122, 0, 0)');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, 60, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ff7a00';
    ctx.beginPath();
    ctx.arc(cx, cy, 32, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`@${currentUsername.slice(0, 8)}`, cx, cy);
    ctx.restore();

    // Planets - inclusive rings for all tracked accounts
    const coreUsers = cachedUsers.filter(u => (u.currentScore || 0) >= 70);
    const closeUsers = cachedUsers.filter(u => (u.currentScore || 0) >= 35 && (u.currentScore || 0) < 70);
    const casualUsers = cachedUsers.filter(u => (u.currentScore || 0) < 35);

    renderHighResPlanets(ctx, coreUsers, cx, cy, rCore, '#f91880');
    renderHighResPlanets(ctx, closeUsers, cx, cy, rClose, '#1d9bf0');
    renderHighResPlanets(ctx, casualUsers, cx, cy, rCasual, '#794bc4');

    // Watermark & Creator Credit
    ctx.fillStyle = '#71767b';
    ctx.font = '14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`BondScore for X • Created by @MaserSuspended • ${new Date().toLocaleDateString()}`, cx, 960);

    // Download PNG
    const link = document.createElement('a');
    link.download = `x_mutuals_orbit_${currentUsername}.png`;
    link.href = exportCanvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    setTimeout(() => link.remove(), 100);

    btn.innerText = '✓ Downloaded!';
    setTimeout(() => {
      btn.innerText = '📸 Share Image';
    }, 2000);
  });
}

function renderHighResPlanets(ctx, users, cx, cy, radius, color) {
  if (!users || users.length === 0) return;
  const count = users.length;
  const angleStep = (Math.PI * 2) / count;
  const pfpRadius = 22;

  users.forEach((u, i) => {
    const angle = i * angleStep;
    const px = cx + Math.cos(angle) * radius;
    const py = cy + Math.sin(angle) * radius;

    ctx.save();
    // Glowing border ring in tier color
    ctx.beginPath();
    ctx.arc(px, py, pfpRadius + 2.5, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();

    const pfp = getLoadedPfp(u.avatarUrl);
    if (pfp) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(px, py, pfpRadius, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(pfp, px - pfpRadius, py - pfpRadius, pfpRadius * 2, pfpRadius * 2);
      ctx.restore();
    } else {
      ctx.beginPath();
      ctx.arc(px, py, pfpRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#16181c';
      ctx.fill();

      ctx.fillStyle = color;
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const initial = (u.displayName || u.handle || 'X').charAt(0).toUpperCase();
      ctx.fillText(initial, px, py);
    }

    // Label
    ctx.font = 'bold 14px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    const labelY = py > cy ? py + pfpRadius + 16 : py - pfpRadius - 6;
    ctx.fillText(`@${u.handle} (${Math.round(u.currentScore || 0)})`, px, labelY);

    ctx.restore();
  });
}

/**
 * ⚙️ Settings Form Handler
 */
async function loadSettingsForm() {
  const settings = await window.bondStorage.getSettings();

  const halfLifeInput = document.getElementById('decay-halflife');
  const halfLifeVal = document.getElementById('decay-halflife-val');
  const graceInput = document.getElementById('grace-period');
  const graceVal = document.getElementById('grace-period-val');
  const weightMutualInput = document.getElementById('weight-mutual');
  const weightMutualVal = document.getElementById('weight-mutual-val');
  const weightReplyInput = document.getElementById('weight-reply');
  const weightReplyVal = document.getElementById('weight-reply-val');
  const weightLikeInput = document.getElementById('weight-like');
  const weightLikeVal = document.getElementById('weight-like-val');

  halfLifeInput.value = settings.decayHalfLifeDays || 14;
  halfLifeVal.innerText = `${halfLifeInput.value} days`;

  graceInput.value = settings.gracePeriodDays ?? 5;
  graceVal.innerText = `${graceInput.value} days`;

  const weights = settings.weights || {};
  weightMutualInput.value = weights.mutualReply || 15;
  weightMutualVal.innerText = `${weightMutualInput.value} pts`;

  weightReplyInput.value = weights.replySent || 8;
  weightReplyVal.innerText = `${weightReplyInput.value} pts`;

  weightLikeInput.value = weights.like || 2;
  weightLikeVal.innerText = `${weightLikeInput.value} pts`;

  halfLifeInput.addEventListener('input', () => halfLifeVal.innerText = `${halfLifeInput.value} days`);
  graceInput.addEventListener('input', () => graceVal.innerText = `${graceInput.value} days`);
  weightMutualInput.addEventListener('input', () => weightMutualVal.innerText = `${weightMutualInput.value} pts`);
  weightReplyInput.addEventListener('input', () => weightReplyVal.innerText = `${weightReplyInput.value} pts`);
  weightLikeInput.addEventListener('input', () => weightLikeVal.innerText = `${weightLikeInput.value} pts`);

  // Multi-Platform Controls
  const platXEnabled = document.getElementById('setting-plat-x-enabled');
  const platXTimeline = document.getElementById('setting-plat-x-timeline');
  const platXDms = document.getElementById('setting-plat-x-dms');

  const platThreadsEnabled = document.getElementById('setting-plat-threads-enabled');
  const platThreadsTimeline = document.getElementById('setting-plat-threads-timeline');
  const platThreadsDms = document.getElementById('setting-plat-threads-dms');

  const platBskyEnabled = document.getElementById('setting-plat-bsky-enabled');
  const platBskyTimeline = document.getElementById('setting-plat-bsky-timeline');
  const platBskyDms = document.getElementById('setting-plat-bsky-dms');

  const platforms = settings.platforms || {
    x: { enabled: true, timeline: true, dms: true },
    threads: { enabled: false, timeline: false, dms: false },
    bsky: { enabled: false, timeline: false, dms: false }
  };

  if (platXEnabled) platXEnabled.checked = platforms.x?.enabled !== false;
  if (platXTimeline) platXTimeline.checked = platforms.x?.timeline !== false;
  if (platXDms) platXDms.checked = platforms.x?.dms !== false;

  if (platThreadsEnabled) platThreadsEnabled.checked = !!platforms.threads?.enabled;
  if (platThreadsTimeline) platThreadsTimeline.checked = !!platforms.threads?.timeline;
  if (platThreadsDms) platThreadsDms.checked = !!platforms.threads?.dms;

  if (platBskyEnabled) platBskyEnabled.checked = !!platforms.bsky?.enabled;
  if (platBskyTimeline) platBskyTimeline.checked = !!platforms.bsky?.timeline;
  if (platBskyDms) platBskyDms.checked = !!platforms.bsky?.dms;

  // Direct Messages & Privacy Controls
  const trackDmsInput = document.getElementById('setting-track-dms');
  const fadingInput = document.getElementById('setting-fading-threshold');
  const fadingVal = document.getElementById('setting-fading-val');
  const dmWeightInput = document.getElementById('setting-dm-weight');
  const dmWeightVal = document.getElementById('setting-dm-weight-val');

  if (trackDmsInput) trackDmsInput.checked = settings.trackDirectMessages !== false;
  if (fadingInput && fadingVal) {
    fadingInput.value = settings.fadingThresholdDays ?? 3;
    fadingVal.innerText = `${fadingInput.value} days`;
    fadingInput.addEventListener('input', () => fadingVal.innerText = `${fadingInput.value} days`);
  }
  if (dmWeightInput && dmWeightVal) {
    dmWeightInput.value = settings.dmScoreWeightPercent ?? 50;
    dmWeightVal.innerText = `${dmWeightInput.value}%`;
    dmWeightInput.addEventListener('input', () => dmWeightVal.innerText = `${dmWeightInput.value}%`);
  }

  // Wire up theme segmented buttons in Settings tab
  const segBtns = document.querySelectorAll('.theme-seg-btn');
  segBtns.forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const themeVal = btn.getAttribute('data-theme');
      await setThemeAndSave(themeVal);
    });
  });

  const saveBtn = document.getElementById('save-settings-btn');
  saveBtn.addEventListener('click', async () => {
    saveBtn.innerText = 'Saving...';
    const current = await window.bondStorage.getSettings();
    await window.bondStorage.updateSettings({
      theme: currentTheme,
      decayHalfLifeDays: parseInt(halfLifeInput.value, 10),
      gracePeriodDays: parseInt(graceInput.value, 10),
      trackDirectMessages: trackDmsInput ? trackDmsInput.checked : true,
      fadingThresholdDays: fadingInput ? parseInt(fadingInput.value, 10) : 3,
      dmScoreWeightPercent: dmWeightInput ? parseInt(dmWeightInput.value, 10) : 50,
      platforms: {
        x: {
          enabled: platXEnabled ? platXEnabled.checked : true,
          timeline: platXTimeline ? platXTimeline.checked : true,
          dms: platXDms ? platXDms.checked : true
        },
        threads: {
          enabled: platThreadsEnabled ? platThreadsEnabled.checked : false,
          timeline: platThreadsTimeline ? platThreadsTimeline.checked : false,
          dms: platThreadsDms ? platThreadsDms.checked : false
        },
        bsky: {
          enabled: platBskyEnabled ? platBskyEnabled.checked : false,
          timeline: platBskyTimeline ? platBskyTimeline.checked : false,
          dms: platBskyDms ? platBskyDms.checked : false
        }
      },
      weights: {
        ...(current.weights || {}),
        mutualReply: parseInt(weightMutualInput.value, 10),
        replySent: parseInt(weightReplyInput.value, 10),
        replyReceived: parseInt(weightReplyInput.value, 10),
        like: parseInt(weightLikeInput.value, 10)
      }
    });
    saveBtn.innerText = '✓ Preferences Saved';
    setTimeout(() => {
      saveBtn.innerText = 'Save Preferences';
    }, 1500);
  });
}

/**
 * 🧠 Render Local Engagement Memory, Balance, Supporters & Dormant Bonds
 */
function renderRadarTab() {
  const streaksList = document.getElementById('streaks-list');
  const supportersList = document.getElementById('supporters-list');
  const outboundList = document.getElementById('outbound-focus-list');
  const dormantList = document.getElementById('dormant-list');

  // Compute local engagement memory metrics
  const memory = BondScoring.analyzeEngagementMemory(cachedUsers);

  // Update Global Balance Card
  const badgeEl = document.getElementById('eng-balance-badge');
  const barSent = document.getElementById('eng-bar-sent');
  const barRecv = document.getElementById('eng-bar-recv');
  const outVal = document.getElementById('eng-outbound-val');
  const outPct = document.getElementById('eng-outbound-pct');
  const inVal = document.getElementById('eng-inbound-val');
  const inPct = document.getElementById('eng-inbound-pct');
  const descEl = document.getElementById('eng-balance-desc');

  if (badgeEl) badgeEl.innerText = memory.balanceLabel;
  if (barSent) barSent.style.width = `${memory.globalSentRatio}%`;
  if (barRecv) barRecv.style.width = `${memory.globalRecvRatio}%`;
  if (outVal) outVal.innerText = memory.totalSent;
  if (outPct) outPct.innerText = `${memory.globalSentRatio}%`;
  if (inVal) inVal.innerText = memory.totalReceived;
  if (inPct) inPct.innerText = `${memory.globalRecvRatio}%`;
  if (descEl) descEl.innerText = memory.balanceDesc;

  // 1. Supporters List (Who engages with you most)
  if (supportersList) {
    const topSupporters = memory.supporters.slice(0, 5);
    if (topSupporters.length > 0) {
      supportersList.innerHTML = topSupporters.map(u => {
        const crm = getCRMStatusForUser(u);
        return `
          <div class="radar-item" style="cursor:pointer;" title="Click to view @${escapeHtml(u.handle)} on X">
            <div class="radar-item-left" onclick="chrome.tabs.create({url:'https://x.com/${escapeHtml(u.handle)}'})">
              ${u.avatarUrl ? `<img class="radar-item-avatar" src="${escapeHtml(u.avatarUrl)}" alt="">` : `<div class="radar-item-avatar" style="background:#ec4899;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">${escapeHtml(u.handle.charAt(0).toUpperCase())}</div>`}
              <span class="radar-item-handle">@${escapeHtml(u.handle)}</span>
              <span class="popup-crm-pill ${crm.id}">${crm.label}</span>
            </div>
            <span class="radar-supporter-val">📥 ${u.received} received</span>
          </div>
        `;
      }).join('');
    } else {
      supportersList.innerHTML = `<div class="radar-empty">No supporter data yet. Interact on X to build memory!</div>`;
    }
  }

  // 2. Outbound Focus (Who you engage with most)
  if (outboundList) {
    const topOutbound = memory.topEngagedByYou.slice(0, 5);
    if (topOutbound.length > 0) {
      outboundList.innerHTML = topOutbound.map(u => `
        <div class="radar-item" style="cursor:pointer;" title="Click to view @${escapeHtml(u.handle)} on X">
          <div class="radar-item-left" onclick="chrome.tabs.create({url:'https://x.com/${escapeHtml(u.handle)}'})">
            ${u.avatarUrl ? `<img class="radar-item-avatar" src="${escapeHtml(u.avatarUrl)}" alt="">` : `<div class="radar-item-avatar" style="background:#1d9bf0;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">${escapeHtml(u.handle.charAt(0).toUpperCase())}</div>`}
            <span class="radar-item-handle">@${escapeHtml(u.handle)}</span>
          </div>
          <span class="radar-outbound-val">📤 ${u.sent} sent</span>
        </div>
      `).join('');
    } else {
      outboundList.innerHTML = `<div class="radar-empty">No outbound data yet.</div>`;
    }
  }

  // 3. Dormant People (No interactions in 14+ days)
  if (dormantList) {
    const topDormant = memory.dormantPeople.slice(0, 5);
    if (topDormant.length > 0) {
      dormantList.innerHTML = topDormant.map(u => `
        <div class="radar-item">
          <div class="radar-item-left">
            ${u.avatarUrl ? `<img class="radar-item-avatar" src="${escapeHtml(u.avatarUrl)}" alt="">` : `<div class="radar-item-avatar" style="background:#71767b;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">${escapeHtml(u.handle.charAt(0).toUpperCase())}</div>`}
            <span class="radar-item-handle">@${escapeHtml(u.handle)}</span>
            <span style="font-size:9px;color:#71767b;">(${Math.round(u.currentScore || 0)} pts)</span>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <span style="font-size:10px;color:#71767b;">❄️ ${u.daysSince}d ago</span>
            <button class="re-engage-btn" data-handle="${escapeHtml(u.handle)}">Say Hi &rarr;</button>
          </div>
        </div>
      `).join('');

      // Wire up re-engage buttons
      dormantList.querySelectorAll('.re-engage-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          chrome.tabs.create({ url: `https://x.com/${btn.dataset.handle}` });
        });
      });
    } else {
      dormantList.innerHTML = `<div class="radar-empty">All tracked bonds are fresh and active!</div>`;
    }
  }

  // 4. Relationship Signals (Follow-backs, Unfollows, Blocks)
  const signalsRadarList = document.getElementById('signals-radar-list');
  if (signalsRadarList) {
    const signalUsers = cachedUsers.filter(u => u.signals && (u.signals.isBlocked || u.signals.isMutual || u.signals.theyFollowYou !== null)).slice(0, 6);
    if (signalUsers.length > 0) {
      signalsRadarList.innerHTML = signalUsers.map(u => {
        const fRel = typeof BondScoring !== 'undefined' && BondScoring.getFollowRelationship
          ? BondScoring.getFollowRelationship(u.signals)
          : null;
        let label = fRel ? fRel.badgeText : '🤝 Mutual Follow';
        let color = fRel ? fRel.color : '#00ba7c';
        return `
          <div class="radar-item" style="cursor:pointer;" title="Click to view @${escapeHtml(u.handle)} on X" onclick="chrome.tabs.create({url:'https://x.com/${escapeHtml(u.handle)}'})">
            <div class="radar-item-left">
              ${u.avatarUrl ? `<img class="radar-item-avatar" src="${escapeHtml(u.avatarUrl)}" alt="">` : `<div class="radar-item-avatar" style="background:#1d9bf0;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">${escapeHtml(u.handle.charAt(0).toUpperCase())}</div>`}
              <span class="radar-item-handle">@${escapeHtml(u.handle)}</span>
            </div>
            <span style="font-size:10px;font-weight:700;color:${color};">${label}</span>
          </div>
        `;
      }).join('');
    } else {
      signalsRadarList.innerHTML = `<div class="radar-empty">No relationship signals detected yet. Visit profiles on X to observe!</div>`;
    }
  }

  // 5. Active streaks
  if (streaksList) {
    const streakUsers = cachedUsers.filter(u => (u.streakDays || 0) > 0).sort((a, b) => (b.streakDays || 0) - (a.streakDays || 0));
    if (streakUsers.length > 0) {
      streaksList.innerHTML = streakUsers.map(u => `
        <div class="radar-item">
          <div class="radar-item-left">
            ${u.avatarUrl ? `<img class="radar-item-avatar" src="${escapeHtml(u.avatarUrl)}" alt="">` : `<div class="radar-item-avatar" style="background:#1d9bf0;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">${escapeHtml(u.handle.charAt(0).toUpperCase())}</div>`}
            <span class="radar-item-handle">@${escapeHtml(u.handle)}</span>
          </div>
          <span class="radar-streak-val">🔥 ${u.streakDays} Day Streak</span>
        </div>
      `).join('');
    } else {
      streaksList.innerHTML = `<div class="radar-empty">No active reply streaks yet. Chat daily with mutuals to ignite streaks!</div>`;
    }
  }

  // 5. Quick deep scanner button
  const deepBtn = document.getElementById('quick-deep-btn');
  const deepInput = document.getElementById('quick-deep-input');
  const deepStatus = document.getElementById('quick-deep-status');

  if (deepBtn && !deepBtn.dataset.bound) {
    deepBtn.dataset.bound = 'true';
    deepBtn.addEventListener('click', async () => {
      const handle = (deepInput.value || '').trim().replace(/^@/, '').toLowerCase();
      if (!handle) return;

      deepBtn.disabled = true;
      deepBtn.innerText = 'Analyzing...';
      deepStatus.style.display = 'block';
      deepStatus.innerText = 'Scanning conversation history...';

      try {
        const currentUser = await window.bondStorage.getCurrentUser() || 'user';
        await window.deepAnalyzer.runAnalysis(currentUser, handle, ({ percent, stage, itemsFound }) => {
          deepStatus.innerText = `${stage} (${itemsFound || 0} found)`;
        });
        deepStatus.innerText = '✓ Analysis complete! Scores updated.';
        deepBtn.innerText = '✓ Done';
        await loadLeaderboard();
        renderRadarTab();
        renderOrbitCanvas();
        setTimeout(() => {
          deepBtn.disabled = false;
          deepBtn.innerText = '⚡ Analyze';
        }, 2000);
      } catch (err) {
        deepStatus.innerText = 'Analysis failed. Make sure you are logged in to X.';
        deepBtn.disabled = false;
        deepBtn.innerText = '⚡ Analyze';
      }
    });
  }
}

/**
 * Sets up the Two-Handle Interaction Lookup component
 */
function setupTwoHandleLookup() {
  const btnSearch = document.getElementById('btn-two-handle-search');
  const btnOpen = document.getElementById('btn-two-handle-open');
  const inputA = document.getElementById('two-handle-a');
  const inputB = document.getElementById('two-handle-b');
  const statusEl = document.getElementById('two-handle-status');
  const resultsEl = document.getElementById('two-handle-results');

  if (!btnSearch || btnSearch.dataset.bound) return;
  btnSearch.dataset.bound = 'true';

  let currentSearchUrl = '';

  btnSearch.addEventListener('click', async () => {
    const handleA = (inputA.value || '').trim().replace(/^@/, '');
    const handleB = (inputB.value || '').trim().replace(/^@/, '');

    if (!handleA || !handleB) {
      statusEl.style.display = 'block';
      statusEl.innerHTML = '<span style="color:#f4212e;">⚠️ Please enter both handles.</span>';
      return;
    }

    if (handleA.toLowerCase() === handleB.toLowerCase()) {
      statusEl.style.display = 'block';
      statusEl.innerHTML = '<span style="color:#f4212e;">⚠️ Please enter two different handles.</span>';
      return;
    }

    btnSearch.disabled = true;
    btnSearch.innerText = 'Searching...';
    btnOpen.style.display = 'none';
    statusEl.style.display = 'block';
    statusEl.innerText = `Searching tweets between @${handleA} and @${handleB}...`;
    resultsEl.style.display = 'none';
    resultsEl.innerHTML = '';

    try {
      const res = await window.deepAnalyzer.lookupInteraction(handleA, handleB, ({ stage }) => {
        statusEl.innerText = stage;
      });

      currentSearchUrl = res.searchUrl;
      btnOpen.style.display = 'inline-block';

      if (res.hasInteracted) {
        statusEl.innerHTML = `<span style="color:#00ba7c;font-weight:700;">✓ Found ${res.totalCount} tweet interaction${res.totalCount > 1 ? 's' : ''}!</span>`;
        resultsEl.style.display = 'flex';
        resultsEl.innerHTML = `
          <div class="two-handle-summary">
            <span>@${escapeHtml(res.handleA)}: ${res.countAtoB}</span>
            <span>•</span>
            <span>@${escapeHtml(res.handleB)}: ${res.countBtoA}</span>
            ${res.lastInteraction ? `<span class="two-handle-last-time">Last: ${BondScoring.formatTimeAgo(res.lastInteraction)}</span>` : ''}
          </div>
          <div class="two-handle-tweets-list">
            ${res.events.slice(0, 5).map(e => `
              <div class="two-handle-tweet-item">
                <span class="two-handle-tweet-type">${e.type === 'reply_sent' ? `@${escapeHtml(res.handleA)} 💬` : e.type === 'quote' ? '🔁 Quote' : '💬 Tweet'}</span>
                <span class="two-handle-tweet-text">${escapeHtml(e.textSnippet || 'Tweet interaction')}</span>
                <span class="two-handle-tweet-time">${BondScoring.formatTimeAgo(e.timestamp)}</span>
              </div>
            `).join('')}
          </div>
        `;
      } else {
        statusEl.innerHTML = `<span style="color:#71767b;">❄️ No tweet interactions found between @${escapeHtml(res.handleA)} and @${escapeHtml(res.handleB)}.</span>`;
        resultsEl.style.display = 'flex';
        resultsEl.innerHTML = `
          <div class="two-handle-empty-hint">
            No public tweet replies found in archives. Click "Open Live on X" to run a live real-time query on X.
          </div>
        `;
      }
    } catch (err) {
      statusEl.innerHTML = `<span style="color:#f4212e;">Error: ${escapeHtml(err.message || 'Lookup failed')}</span>`;
    } finally {
      btnSearch.disabled = false;
      btnSearch.innerText = '⚡ Check Tweets';
    }
  });

  btnOpen.addEventListener('click', () => {
    if (currentSearchUrl) {
      chrome.tabs.create({ url: currentSearchUrl });
    }
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* ==========================================================================
   💬 Direct Messages & Group Chats Dashboard Logic (v1.2)
   ========================================================================== */

let cachedDms = [];
let currentDmFilter = 'all';

function setupDmFilterPills() {
  const pills = document.querySelectorAll('#dm-filter-pills .filter-pill');
  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentDmFilter = pill.dataset.dmFilter || 'all';
      renderDmSubSections(cachedDms, currentDmFilter);
    });
  });
}

function setupDmSearchHandler() {
  const searchInput = document.getElementById('dm-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      renderDmSubSections(cachedDms, currentDmFilter);
    });
  }
}

/**
 * 💬 Render DMs & Group Chats Analytics and Relationship System
 */
async function renderDmsTab() {
  const activeAcc = (currentUsername && currentUsername !== 'you') ? currentUsername : null;
  const allDms = await window.bondStorage.getAllDmConversations(activeAcc, currentPlatformFilter);
  cachedDms = allDms;

  const total = allDms.length;
  const waitingList = allDms.filter(d => d.waitingForUserReply === true);
  const waitingCount = waitingList.length;

  const allReplyTimes = [];
  let streakSum = 0;
  allDms.forEach(d => {
    if (d.medianReplyTimeMs > 0) allReplyTimes.push(d.medianReplyTimeMs);
    if (d.dailyStreak > 1) streakSum++;
  });

  let avgSpeedText = '-';
  if (allReplyTimes.length > 0) {
    const avgMs = Math.round(allReplyTimes.reduce((a, b) => a + b, 0) / allReplyTimes.length);
    avgSpeedText = BondScoring.formatDuration ? BondScoring.formatDuration(avgMs) : `${Math.round(avgMs / 60000)}m`;
  }

  const statTotal = document.getElementById('dm-stat-total');
  const statWaiting = document.getElementById('dm-stat-waiting');
  const statSpeed = document.getElementById('dm-stat-speed');
  const statStreaks = document.getElementById('dm-stat-streaks');
  const statBoxWaiting = document.getElementById('dm-stat-box-waiting');

  if (statTotal) statTotal.innerText = total;
  if (statWaiting) statWaiting.innerText = waitingCount;
  if (statSpeed) statSpeed.innerText = avgSpeedText;
  if (statStreaks) statStreaks.innerText = streakSum;

  if (statBoxWaiting) {
    statBoxWaiting.classList.toggle('has-waiting', waitingCount > 0);
  }

  renderDmSubSections(allDms, currentDmFilter);
}

function renderDmSubSections(allDms, filter = 'all') {
  const searchInput = document.getElementById('dm-search-input');
  const query = (searchInput ? searchInput.value : '').toLowerCase().trim();

  let filtered = allDms;
  if (query) {
    filtered = filtered.filter(d => {
      const title = (d.title || '').toLowerCase();
      const id = (d.convId || '').toLowerCase();
      const parts = Array.isArray(d.participants) ? d.participants.join(' ').toLowerCase() : '';
      return title.includes(query) || id.includes(query) || parts.includes(query);
    });
  }

  // 1. Waiting for your reply
  const sectionWaiting = document.getElementById('dm-section-waiting');
  const listWaiting = document.getElementById('dm-waiting-list');
  const countWaiting = document.getElementById('dm-waiting-count');
  const waitingItems = filtered.filter(d => d.waitingForUserReply === true);

  if (countWaiting) countWaiting.innerText = waitingItems.length;
  if (sectionWaiting && listWaiting) {
    const showWaiting = filter === 'waiting' || (filter === 'all' && waitingItems.length > 0);
    sectionWaiting.style.display = showWaiting ? 'block' : 'none';

    if (waitingItems.length === 0) {
      listWaiting.innerHTML = '<div class="dm-empty-state">🎉 All caught up! Zero conversations waiting on your reply.</div>';
    } else {
      listWaiting.innerHTML = waitingItems.map(d => {
        const title = d.title || (d.participants && d.participants[0]) || d.convId;
        const details = d.participantDetails && d.participants && d.participantDetails[d.participants[0]];
        const avatar = details ? details.avatarUrl : '';
        const waitTime = d.formattedWaitingDuration || (BondScoring.formatDuration ? BondScoring.formatDuration(d.waitingDurationMs || 0) : 'recently');
        const rank = d.rank || BondScoring.getDmRank(d.bondScore || 0);

        return `
          <div class="dm-action-row" data-conv="${escapeHtml(d.convId)}">
            <div class="dm-action-avatar">
              ${avatar ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(title)}">` : `<div class="dm-avatar-fallback">${escapeHtml(title.charAt(0).toUpperCase())}</div>`}
            </div>
            <div class="dm-action-meta">
              <div class="dm-action-title-row">
                <span class="dm-action-title">${escapeHtml(title)}</span>
                <span class="bond-rank-tag bond-rank-${rank.id}">${rank.emoji} ${rank.shortLabel}</span>
              </div>
              <div class="dm-action-sub">
                <span class="dm-wait-tag">⏳ Waiting ${waitTime}</span>
                <span>• ${d.replyRate ?? 100}% reply rate</span>
              </div>
            </div>
            <button class="dm-reply-btn" data-url="https://x.com/messages/${escapeHtml(d.convId)}">Reply ↗</button>
          </div>
        `;
      }).join('');
    }
  }

  // 2. Who Should I Message? (Anti-Fading Smart List)
  const sectionCold = document.getElementById('dm-section-cold');
  const listCold = document.getElementById('dm-cold-list');
  const countCold = document.getElementById('dm-cold-count');
  const coldItems = filtered.filter(d => !d.isGroup && (d.isCoolingCandidate === true || d.isFading === true));

  if (countCold) countCold.innerText = coldItems.length;
  if (sectionCold && listCold) {
    const showCold = filter === 'cold' || (filter === 'all' && coldItems.length > 0);
    sectionCold.style.display = showCold ? 'block' : 'none';

    if (coldItems.length === 0) {
      listCold.innerHTML = '<div class="dm-empty-state">🔥 All high-bond relationships are warm and active!</div>';
    } else {
      listCold.innerHTML = coldItems.map(d => {
        const title = d.title || (d.participants && d.participants[0]) || d.convId;
        const details = d.participantDetails && d.participants && d.participantDetails[d.participants[0]];
        const avatar = details ? details.avatarUrl : '';
        const rank = d.rank || BondScoring.getDmRank(d.bondScore || 0);
        const days = d.daysSinceLast || Math.floor((Date.now() - (d.lastMessageTimestamp || Date.now())) / 86400000);

        return `
          <div class="dm-action-row cold-row" data-conv="${escapeHtml(d.convId)}">
            <div class="dm-action-avatar">
              ${avatar ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(title)}">` : `<div class="dm-avatar-fallback">${escapeHtml(title.charAt(0).toUpperCase())}</div>`}
            </div>
            <div class="dm-action-meta">
              <div class="dm-action-title-row">
                <span class="dm-action-title">${escapeHtml(title)}</span>
                <span class="bond-rank-tag bond-rank-${rank.id}">${rank.emoji} ${rank.name}</span>
              </div>
              <div class="dm-action-sub">
                <span class="dm-cold-tag">🧊 Quiet for ${days} days</span>
                <span>• Was Bond ${Math.round(d.bondScore || 0)}</span>
              </div>
            </div>
            <button class="dm-reconnect-btn" data-url="https://x.com/messages/${escapeHtml(d.convId)}">Say Hi ↗</button>
          </div>
        `;
      }).join('');
    }
  }

  // 3. Closest Friends (1:1 Leaderboard)
  const sectionClosest = document.getElementById('dm-section-closest');
  const listClosest = document.getElementById('dm-closest-list');
  const countClosest = document.getElementById('dm-closest-count');
  let closestItems = filtered.filter(d => !d.isGroup && (d.bondScore || 0) > 0);
  if (filter === 'streaks') closestItems = closestItems.filter(d => (d.dailyStreak || 0) > 1);
  closestItems.sort((a, b) => (b.bondScore || 0) - (a.bondScore || 0));

  if (countClosest) countClosest.innerText = closestItems.length;
  if (sectionClosest && listClosest) {
    const showClosest = filter !== 'groups' && filter !== 'cold' && filter !== 'waiting';
    sectionClosest.style.display = showClosest ? 'block' : 'none';

    if (closestItems.length === 0) {
      listClosest.innerHTML = '<div class="dm-empty-state">No direct messages tracked yet. Chat on X to build your private bond scores!</div>';
    } else {
      listClosest.innerHTML = closestItems.map((d, idx) => {
        const title = d.title || (d.participants && d.participants[0]) || d.convId;
        const details = d.participantDetails && d.participants && d.participantDetails[d.participants[0]];
        const avatar = details ? details.avatarUrl : '';
        const rank = d.rank || BondScoring.getDmRank(d.bondScore || 0);
        const score = Math.round(d.bondScore || 0);
        const sentPct = d.sentPercent ?? (d.totalCount > 0 ? Math.round((d.sentCount / d.totalCount) * 100) : 50);
        const recvPct = 100 - sentPct;

        return `
          <div class="dm-closest-card" data-conv="${escapeHtml(d.convId)}">
            <div class="dm-closest-top">
              <div class="dm-closest-user">
                <span class="dm-closest-rank-num">#${idx + 1}</span>
                <div class="dm-action-avatar">
                  ${avatar ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(title)}">` : `<div class="dm-avatar-fallback">${escapeHtml(title.charAt(0).toUpperCase())}</div>`}
                </div>
                <div class="dm-closest-names">
                  <div class="dm-closest-name-row">
                    <strong class="dm-closest-name">${escapeHtml(title)}</strong>
                    <span class="bond-rank-tag bond-rank-${rank.id}">${rank.emoji} ${rank.name}</span>
                  </div>
                  <div class="dm-closest-metrics-row">
                    <span>⚡ ${d.formattedMedianReply || 'fast'}</span>
                    ${d.dailyStreak > 1 ? `<span class="dm-streak-chip">🔥 ${d.dailyStreak}d</span>` : ''}
                    <span>📬 ${d.replyRate ?? 100}% reply</span>
                  </div>
                </div>
              </div>
              <div class="dm-closest-score-badge" style="color: ${rank.color}; border: 1px solid ${rank.color}40; background: ${rank.bg}">
                <span>${score}</span>
              </div>
            </div>

            <!-- Balance Bar -->
            <div class="dm-card-balance-wrap">
              <div class="dm-card-balance-sent" style="width: ${sentPct}%;"></div>
              <div class="dm-card-balance-recv" style="width: ${recvPct}%;"></div>
            </div>
            <div class="dm-card-balance-labels">
              <span>You: ${d.sentCount || 0} (${sentPct}%)</span>
              <button class="dm-open-btn" data-url="https://x.com/messages/${escapeHtml(d.convId)}">Open ↗</button>
              <span>Them: ${d.receivedCount || 0} (${recvPct}%)</span>
            </div>
          </div>
        `;
      }).join('');
    }
  }

  // 4. Group Chats
  const sectionGroups = document.getElementById('dm-section-groups');
  const listGroups = document.getElementById('dm-groups-list');
  const countGroups = document.getElementById('dm-groups-count');
  const groupItems = filtered.filter(d => d.isGroup === true);
  groupItems.sort((a, b) => (b.groupEnergyScore || 0) - (a.groupEnergyScore || 0));

  if (countGroups) countGroups.innerText = groupItems.length;
  if (sectionGroups && listGroups) {
    const showGroups = filter === 'groups' || (filter === 'all' && groupItems.length > 0);
    sectionGroups.style.display = showGroups ? 'block' : 'none';

    if (groupItems.length === 0) {
      listGroups.innerHTML = '<div class="dm-empty-state">No group chats detected yet. Participate in group conversations on X to observe group energy!</div>';
    } else {
      listGroups.innerHTML = groupItems.map(d => {
        const energyLevel = d.groupEnergyLevel || BondScoring.getGroupEnergyLevel(d.groupEnergyScore || 0);
        const score = Math.round(d.groupEnergyScore || 0);
        const activeMembers = (d.energyMetrics && d.energyMetrics.activeMembers) || [];

        return `
          <div class="dm-group-card" data-conv="${escapeHtml(d.convId)}">
            <div class="dm-group-header">
              <div class="dm-group-info">
                <span class="dm-group-icon">👥</span>
                <div>
                  <strong class="dm-group-title">${escapeHtml(d.title || 'Group Chat')}</strong>
                  <div class="dm-group-sub">${activeMembers.length || (d.participants ? d.participants.length : 1)} active participants</div>
                </div>
              </div>
              <div class="bond-energy-tag bond-energy-${energyLevel.id}">
                ${energyLevel.emoji} ${energyLevel.name} ${score}
              </div>
            </div>

            <!-- Active Member Chips -->
            <div class="dm-group-chips">
              ${activeMembers.slice(0, 4).map(m => `
                <span class="dm-member-chip">@${escapeHtml(m.handle)} (${m.share}%)</span>
              `).join('')}
            </div>

            <div class="dm-group-footer">
              <span class="dm-group-activity">${d.isDying ? '⚠️ Group is quiet / dormant' : `🔥 ${d.totalMessages || 0} messages recorded`}</span>
              <button class="dm-open-btn" data-url="https://x.com/messages/${escapeHtml(d.convId)}">Open Group ↗</button>
            </div>
          </div>
        `;
      }).join('');
    }
  }

  // 5. Chat Memories & Milestones (Lifetime Log)
  const sectionMemories = document.getElementById('dm-section-memories');
  const listMemories = document.getElementById('dm-memories-list');
  const countMemories = document.getElementById('dm-memories-count');

  const allMilestones = [];
  filtered.forEach(d => {
    if (Array.isArray(d.memories)) {
      d.memories.forEach(m => {
        allMilestones.push({
          ...m,
          convId: d.convId,
          convTitle: d.title || (d.participants && d.participants[0]) || d.convId
        });
      });
    }
  });
  allMilestones.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  const topLifetime = [...filtered].sort((a, b) => (b.lifetimeTotal || b.totalCount || 0) - (a.lifetimeTotal || a.totalCount || 0));

  if (countMemories) countMemories.innerText = allMilestones.length || topLifetime.filter(d => (d.lifetimeTotal || d.totalCount) > 0).length;

  if (sectionMemories && listMemories) {
    const showMemories = filter === 'memories' || (filter === 'all' && (topLifetime.length > 0 || allMilestones.length > 0));
    sectionMemories.style.display = showMemories ? 'block' : 'none';

    if (topLifetime.length === 0 && allMilestones.length === 0) {
      listMemories.innerHTML = '<div class="dm-empty-state">💭 No chat memories recorded yet. Chat on X to build your permanent memory ledger!</div>';
    } else {
      let html = '';

      // Top Lifetime Chats
      if (topLifetime.length > 0 && (topLifetime[0].lifetimeTotal || topLifetime[0].totalCount || 0) > 0) {
        html += `
          <div class="dm-memory-subhead">🌟 All-Time Chat Champions (Lifetime Volume)</div>
          <div class="dm-champions-grid">
            ${topLifetime.slice(0, 3).map((d) => {
              const title = d.title || (d.participants && d.participants[0]) || d.convId;
              const details = d.participantDetails && d.participants && d.participantDetails[d.participants[0]];
              const avatar = details ? details.avatarUrl : '';
              const rank = d.rank || BondScoring.getDmRank(d.bondScore || 0);
              const lifetime = d.lifetimeTotal || d.totalCount || 0;
              return `
                <div class="dm-champion-card" data-conv="${escapeHtml(d.convId)}">
                  <div class="dm-action-avatar">
                    ${avatar ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(title)}">` : `<div class="dm-avatar-fallback">${escapeHtml(title.charAt(0).toUpperCase())}</div>`}
                  </div>
                  <div class="dm-champ-info">
                    <strong class="dm-champ-title">${escapeHtml(title)}</strong>
                    <span class="dm-champ-count">${lifetime} lifetime msgs</span>
                    <span class="bond-rank-tag bond-rank-${rank.id}">${rank.emoji} ${rank.shortLabel}</span>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        `;
      }

      // Recent Milestone Feed
      if (allMilestones.length > 0) {
        html += `
          <div class="dm-memory-subhead" style="margin-top: 10px;">📜 Recent Milestone Moments</div>
          <div class="dm-milestones-feed">
            ${allMilestones.slice(0, 5).map(m => `
              <div class="dm-milestone-item">
                <span class="dm-milestone-badge">${m.badge || '✨'}</span>
                <div class="dm-milestone-info">
                  <div class="dm-milestone-title-row">
                    <strong>${escapeHtml(m.title)}</strong>
                    <span class="dm-milestone-date">${new Date(m.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>
                  </div>
                  <span class="dm-milestone-desc">${escapeHtml(m.description)}</span>
                </div>
              </div>
            `).join('')}
          </div>
        `;
      }

      listMemories.innerHTML = html;
    }
  }

  // Wire up Open/Reply buttons to launch X messages
  const actionBtns = document.querySelectorAll('.dm-reply-btn, .dm-reconnect-btn, .dm-open-btn');
  actionBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const url = btn.getAttribute('data-url');
      if (url && typeof chrome !== 'undefined' && chrome.tabs) {
        chrome.tabs.create({ url });
      }
    });
  });
}
